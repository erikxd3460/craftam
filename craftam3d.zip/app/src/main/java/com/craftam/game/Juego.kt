package com.craftam.game

import android.content.Context
import android.util.Log
import org.json.JSONObject
import java.io.File

/** Todo el estado de la partida. Se actualiza desde el hilo de OpenGL. */
class Juego(private val ctx: Context) {
    val mundo: Mundo
    val jug = Jugador()
    val inv = Inventario()
    private val alcance = Datos.fis.getDouble("alcance").toFloat()

    @Volatile var objetivo: Golpe? = null
    @Volatile var prog = 0f            // 0..1 progreso de romper el bloque
    private var previo: Golpe? = null
    private var acum = 0f

    init {
        val c = Datos.mundo
        mundo = Mundo(c.getInt("chunks"), c.getInt("chunks"), c.getInt("altura"), c.getInt("semilla"))
        jug.x = mundo.spawnX + 0.5f; jug.z = mundo.spawnZ + 0.5f
        jug.y = mundo.alturaSup(mundo.spawnX, mundo.spawnZ) + 1f
        cargar()
    }

    private fun mismo(a: Golpe?, b: Golpe) = a != null && a.x == b.x && a.y == b.y && a.z == b.z

    fun actualizar(dt: Float) {
        val m = Entrada.tomarMirar()
        jug.yaw += m[0]
        jug.pitch = (jug.pitch - m[1]).coerceIn(-1.5f, 1.5f)
        if (jug.mover(mundo, dt, Entrada.jx, Entrada.jy, Entrada.saltar)) Sonido.tocar("saltar")

        val d = jug.mirar()
        val g = mundo.rayo(jug.x, jug.y + jug.ojos, jug.z, d[0], d[1], d[2], alcance)
        objetivo = if (g != null && mundo.dentro(g.x, g.y, g.z)) g else null

        val o = objetivo
        if (Entrada.picar && o != null && o.y > 0) {
            if (!mismo(previo, o)) { previo = o; acum = 0f }
            val bloque = Datos.obj(mundo.get(o.x, o.y, o.z))
            acum += dt * inv.poder()
            prog = (acum / bloque.dureza).coerceIn(0f, 1f)
            if (acum >= bloque.dureza) romper(o, bloque)
        } else { acum = 0f; prog = 0f; previo = null }

        if (Entrada.tomarPoner() && g != null) poner(g)
    }

    private fun romper(g: Golpe, b: Obj) {
        mundo.poner(g.x, g.y, g.z, 0)
        if (!b.requierePico || inv.poder() > 1) inv.dar(b.suelta)
        Sonido.tocar("romper")
        acum = 0f; prog = 0f; previo = null
    }

    private fun poner(g: Golpe) {
        if (g.nx == 0 && g.ny == 0 && g.nz == 0) return
        val x = g.x + g.nx; val y = g.y + g.ny; val z = g.z + g.nz
        val id = inv.actual()
        if (id == 0 || !Datos.obj(id).esBloque) return
        if (!mundo.dentro(x, y, z) || mundo.get(x, y, z) != 0 || jug.ocupa(x, y, z)) return
        mundo.poner(x, y, z, id)
        inv.quitar(id)
        Sonido.tocar("poner")
    }

    fun craftear(r: Receta): Boolean {
        val ok = inv.craftear(r)
        if (ok) Sonido.tocar("craft")
        return ok
    }

    // ---------- guardado ----------
    private fun archivoMundo() = File(ctx.filesDir, "mundo.bin")
    private fun archivoPartida() = File(ctx.filesDir, "partida.json")

    fun guardar() {
        try {
            mundo.guardar(archivoMundo())
            val o = JSONObject()
            o.put("x", jug.x.toDouble()); o.put("y", jug.y.toDouble()); o.put("z", jug.z.toDouble())
            o.put("yaw", jug.yaw.toDouble()); o.put("pitch", jug.pitch.toDouble())
            o.put("inv", inv.exportar())
            archivoPartida().writeText(o.toString())
        } catch (e: Exception) { Log.e("Craftam", "No se pudo guardar", e) }
    }

    private fun cargar() {
        try {
            if (!archivoPartida().exists() || !mundo.cargar(archivoMundo())) return
            val o = JSONObject(archivoPartida().readText())
            jug.x = o.getDouble("x").toFloat(); jug.y = o.getDouble("y").toFloat(); jug.z = o.getDouble("z").toFloat()
            jug.yaw = o.getDouble("yaw").toFloat(); jug.pitch = o.getDouble("pitch").toFloat()
            inv.importar(o.getJSONArray("inv"))
        } catch (e: Exception) { Log.e("Craftam", "No se pudo cargar", e) }
    }

    companion object {
        fun borrarPartida(c: Context) {
            File(c.filesDir, "mundo.bin").delete(); File(c.filesDir, "partida.json").delete()
        }
    }
}
