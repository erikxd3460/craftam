package com.craftam.game

import android.app.Activity
import android.app.AlertDialog
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout

class JuegoActivity : Activity() {
    private lateinit var gl: GLSurfaceView
    private lateinit var juego: Juego

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        Assets.init(this); Datos.cargar(); Atlas.construir(); Sonido.init(this)
        Entrada.reset()
        juego = Juego(this)

        gl = GLSurfaceView(this)
        gl.setEGLContextClientVersion(2)
        gl.setRenderer(Render(juego))

        val raiz = FrameLayout(this)
        val tam = ViewGroup.LayoutParams.MATCH_PARENT
        raiz.addView(gl, FrameLayout.LayoutParams(tam, tam))
        raiz.addView(HudView(this, juego) { mostrarCraft() }, FrameLayout.LayoutParams(tam, tam))
        setContentView(raiz)
    }

    private fun mostrarCraft() {
        val rs = Datos.recetas
        val textos = rs.map { r ->
            val ing = r.necesita.joinToString(" + ") { it.second.toString() + " " + Datos.obj(it.first).nombre }
            (if (juego.inv.puede(r)) "[OK] " else "[--] ") + r.cantidad + " " + Datos.obj(r.da).nombre + "  <-  " + ing
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Crafteo")
            .setItems(textos) { _, i -> juego.craftear(rs[i]); mostrarCraft() }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(f: Boolean) {
        super.onWindowFocusChanged(f)
        if (f) window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
    }

    override fun onResume() { super.onResume(); gl.onResume() }

    override fun onPause() {
        super.onPause()
        gl.onPause()          // espera a que el hilo de dibujo se detenga
        juego.guardar()
    }
}
