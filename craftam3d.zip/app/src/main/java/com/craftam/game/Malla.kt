package com.craftam.game

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint

/** Junta todas las texturas de bloques en una sola imagen (atlas) de 8x8 casillas de 16px. */
object Atlas {
    const val COLS = 8
    const val T = 16
    private var listo = false
    var negro = 0
    lateinit var bmp: Bitmap
    val cara = HashMap<Int, IntArray>()     // id de bloque -> casilla por cara (+X,-X,+Y,-Y,+Z,-Z)

    fun construir() {
        if (listo) return
        val indice = HashMap<String, Int>()
        val nombres = LinkedHashSet<String>()
        for (o in Datos.objs.values) if (o.esBloque) { nombres.add(o.arriba); nombres.add(o.lado); nombres.add(o.abajo) }
        val b = Bitmap.createBitmap(COLS * T, COLS * T, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        var i = 0
        for (n in nombres) {
            c.drawBitmap(Assets.bitmap("$GH/block/$n"), ((i % COLS) * T).toFloat(), ((i / COLS) * T).toFloat(), null)
            indice[n] = i; i++
        }
        negro = i
        val p = Paint(); p.color = Color.BLACK
        val nx = ((i % COLS) * T).toFloat(); val ny = ((i / COLS) * T).toFloat()
        c.drawRect(nx, ny, nx + T, ny + T, p)
        bmp = b
        for (o in Datos.objs.values) if (o.esBloque) {
            val t = indice.getValue(o.arriba); val l = indice.getValue(o.lado); val a = indice.getValue(o.abajo)
            cara[o.id] = intArrayOf(l, l, t, a, l, l)
        }
        listo = true
    }
}

/** Convierte los bloques de un chunk en triangulos (solo las caras que se ven). Formato: x,y,z,u,v,sombra. */
object Mallador {
    // Esquinas de cada cara: +X, -X, +Y, -Y, +Z, -Z
    private val ESQ = arrayOf(
        intArrayOf(1, 0, 0, 1, 1, 0, 1, 1, 1, 1, 0, 1),
        intArrayOf(0, 0, 1, 0, 1, 1, 0, 1, 0, 0, 0, 0),
        intArrayOf(0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0),
        intArrayOf(0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0, 1),
        intArrayOf(1, 0, 1, 1, 1, 1, 0, 1, 1, 0, 0, 1),
        intArrayOf(0, 0, 0, 0, 1, 0, 1, 1, 0, 1, 0, 0))
    private val DIR = arrayOf(intArrayOf(1, 0, 0), intArrayOf(-1, 0, 0), intArrayOf(0, 1, 0),
        intArrayOf(0, -1, 0), intArrayOf(0, 0, 1), intArrayOf(0, 0, -1))
    private val SOMBRA = floatArrayOf(0.8f, 0.8f, 1f, 0.5f, 0.65f, 0.65f)
    private val UV = intArrayOf(0, 1, 0, 0, 1, 0, 1, 1)    // (u,v) por esquina: 0 o 1
    private val TRI = intArrayOf(0, 1, 2, 0, 2, 3)

    var buf = FloatArray(1 shl 16)
    private var n = 0

    private fun v(x: Float, y: Float, z: Float, u: Float, vv: Float, s: Float) {
        if (n + 6 > buf.size) buf = buf.copyOf(buf.size * 2)
        buf[n++] = x; buf[n++] = y; buf[n++] = z; buf[n++] = u; buf[n++] = vv; buf[n++] = s
    }

    /** Llena `buf` con el chunk (a,c) y devuelve cuantos floats uso. */
    fun construir(m: Mundo, a: Int, c: Int): Int {
        n = 0
        val paso = 1f / Atlas.COLS
        val eps = 0.0005f
        for (x in a * 16 until a * 16 + 16) for (z in c * 16 until c * 16 + 16) for (y in 0 until m.alto) {
            val id = m.get(x, y, z)
            if (id == 0) continue
            val tiles = Atlas.cara[id] ?: continue
            for (d in 0 until 6) {
                val dd = DIR[d]
                if (m.get(x + dd[0], y + dd[1], z + dd[2]) != 0) continue
                val t = tiles[d]
                val u0 = (t % Atlas.COLS) * paso + eps; val u1 = (t % Atlas.COLS + 1) * paso - eps
                val v0 = (t / Atlas.COLS) * paso + eps; val v1 = (t / Atlas.COLS + 1) * paso - eps
                val e = ESQ[d]
                for (k in TRI) {
                    v((x + e[k * 3]).toFloat(), (y + e[k * 3 + 1]).toFloat(), (z + e[k * 3 + 2]).toFloat(),
                        if (UV[k * 2] == 0) u0 else u1, if (UV[k * 2 + 1] == 0) v0 else v1, SOMBRA[d])
                }
            }
        }
        return n
    }

    /** Cubo negro (un poco mas grande que un bloque) para marcar el progreso al picar. */
    fun cubo(): FloatArray {
        val o = FloatArray(36 * 6); var k = 0
        val t = Atlas.negro
        val u = ((t % Atlas.COLS) + 0.5f) / Atlas.COLS; val vv = ((t / Atlas.COLS) + 0.5f) / Atlas.COLS
        for (d in 0 until 6) for (q in TRI) {
            val e = ESQ[d]
            o[k++] = e[q * 3] * 1.004f - 0.002f; o[k++] = e[q * 3 + 1] * 1.004f - 0.002f; o[k++] = e[q * 3 + 2] * 1.004f - 0.002f
            o[k++] = u; o[k++] = vv; o[k++] = 1f
        }
        return o
    }

    /** Las 12 aristas del cubo, para dibujar el contorno del bloque al que apuntas. */
    fun aristas(): FloatArray {
        val o = FloatArray(24 * 6); var k = 0
        val t = Atlas.negro
        val u = ((t % Atlas.COLS) + 0.5f) / Atlas.COLS; val vv = ((t / Atlas.COLS) + 0.5f) / Atlas.COLS
        for (i in 0 until 8) for (bit in 0 until 3) {
            if ((i and (1 shl bit)) != 0) continue
            val j = i or (1 shl bit)
            for (p in intArrayOf(i, j)) {
                o[k++] = (p and 1) * 1.004f - 0.002f; o[k++] = ((p shr 1) and 1) * 1.004f - 0.002f; o[k++] = ((p shr 2) and 1) * 1.004f - 0.002f
                o[k++] = u; o[k++] = vv; o[k++] = 1f
            }
        }
        return o
    }
}
