package com.craftam.game

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.json.JSONArray
import org.json.JSONObject

const val GH = "Craftam GH"
const val TC = "Tactil-controles"

/** Lee archivos de la carpeta assets (json y png). */
object Assets {
    private lateinit var ctx: Context
    fun init(c: Context) { ctx = c.applicationContext }
    fun json(ruta: String) = JSONObject(ctx.assets.open(ruta).bufferedReader().use { it.readText() })
    fun bitmap(ruta: String): Bitmap = ctx.assets.open(ruta).use { BitmapFactory.decodeStream(it) }
}

class Obj(
    val id: Int, val nombre: String, val esBloque: Boolean, val dureza: Float, val suelta: Int,
    val requierePico: Boolean, val poder: Int, val arriba: String, val lado: String, val abajo: String, val icono: String
) {
    val carpeta: String get() = if (esBloque) "block" else "item"
}

class Receta(val nombre: String, val da: Int, val cantidad: Int, val necesita: List<Pair<Int, Int>>)

object Datos {
    val objs = HashMap<Int, Obj>()
    val recetas = ArrayList<Receta>()
    lateinit var mundo: JSONObject
    lateinit var arbol: JSONObject
    lateinit var fis: JSONObject
    lateinit var hud: JSONObject
    lateinit var menu: JSONObject
    private var listo = false

    fun cargar() {
        if (listo) return
        val bl = Assets.json("$GH/block/bloques.json").getJSONArray("bloques")
        for (i in 0 until bl.length()) {
            val o = bl.getJSONObject(i)
            val id = o.getInt("id"); val t = o.getString("textura")
            objs[id] = Obj(id, o.getString("nombre"), true, o.getDouble("dureza").toFloat(), o.optInt("suelta", id),
                o.optBoolean("requiere_pico", false), 1, o.optString("top", t), o.optString("lado", t), o.optString("abajo", t), t)
        }
        val its = Assets.json("$GH/item/items.json").getJSONArray("items")
        for (i in 0 until its.length()) {
            val o = its.getJSONObject(i)
            val id = o.getInt("id"); val t = o.getString("textura")
            objs[id] = Obj(id, o.getString("nombre"), false, 0f, id, false, o.getInt("poder"), t, t, t, t)
        }
        val rs = Assets.json("$GH/crafteo/recetas.json").getJSONArray("recetas")
        for (i in 0 until rs.length()) {
            val r = rs.getJSONObject(i)
            val da = r.getJSONArray("da"); val ne = r.getJSONArray("necesita")
            val lista = ArrayList<Pair<Int, Int>>()
            for (k in 0 until ne.length()) lista.add(Pair(ne.getJSONArray(k).getInt(0), ne.getJSONArray(k).getInt(1)))
            recetas.add(Receta(r.getString("nombre"), da.getInt(0), da.getInt(1), lista))
        }
        mundo = Assets.json("world/world.json")
        arbol = Assets.json("world/extructures/arbol.json")
        fis = Assets.json("$GH/model/jugador.json")
        hud = Assets.json("$TC/tactil.json")
        menu = Assets.json("menu/MenGd.json")
        listo = true
    }

    fun obj(id: Int): Obj = objs.getValue(id)
}

class Inventario {
    private val c = LinkedHashMap<Int, Int>()
    @Volatile var sel = 0

    @Synchronized fun dar(id: Int, n: Int = 1) { c[id] = (c[id] ?: 0) + n }

    @Synchronized fun quitar(id: Int, n: Int = 1) {
        val v = (c[id] ?: 0) - n
        if (v <= 0) c.remove(id) else c[id] = v
        if (sel >= c.size) sel = maxOf(0, c.size - 1)
    }

    @Synchronized fun actual(): Int = c.keys.elementAtOrNull(sel) ?: 0
    @Synchronized fun poder(): Int = maxOf(1, c.keys.maxOfOrNull { Datos.obj(it).poder } ?: 1)
    @Synchronized fun puede(r: Receta): Boolean = r.necesita.all { (c[it.first] ?: 0) >= it.second }

    @Synchronized fun craftear(r: Receta): Boolean {
        if (!puede(r)) return false
        for (p in r.necesita) quitar(p.first, p.second)
        dar(r.da, r.cantidad)
        return true
    }

    @Synchronized fun lista(): List<IntArray> = c.map { intArrayOf(it.key, it.value) }
    @Synchronized fun seleccionar(i: Int) { if (i >= 0 && i < c.size) sel = i }

    @Synchronized fun exportar(): JSONArray {
        val a = JSONArray()
        for ((k, v) in c) a.put(JSONArray().put(k).put(v))
        return a
    }

    @Synchronized fun importar(a: JSONArray) {
        c.clear()
        for (i in 0 until a.length()) {
            val p = a.getJSONArray(i)
            if (Datos.objs.containsKey(p.getInt(0))) c[p.getInt(0)] = p.getInt(1)
        }
        sel = 0
    }
}

/** Estado de los controles tactiles (lo escribe la interfaz, lo lee el juego). */
object Entrada {
    @Volatile var jx = 0f
    @Volatile var jy = 0f
    @Volatile var saltar = false
    @Volatile var picar = false
    @Volatile private var poner = false
    private var mx = 0f
    private var my = 0f

    @Synchronized fun mirar(dx: Float, dy: Float) { mx += dx; my += dy }
    @Synchronized fun tomarMirar(): FloatArray { val r = floatArrayOf(mx, my); mx = 0f; my = 0f; return r }
    fun pedirPoner() { poner = true }
    fun tomarPoner(): Boolean { val r = poner; poner = false; return r }
    @Synchronized fun reset() { jx = 0f; jy = 0f; saltar = false; picar = false; poner = false; mx = 0f; my = 0f }
}
