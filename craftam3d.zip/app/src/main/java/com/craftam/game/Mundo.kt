package com.craftam.game

import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin

class Golpe(val x: Int, val y: Int, val z: Int, val nx: Int, val ny: Int, val nz: Int)

/** Mundo de bloques: b[(x*largo+z)*alto+y]. Cada chunk son 16x16 columnas. */
class Mundo(val cx: Int, val cz: Int, val alto: Int, private val semilla: Int) {
    val ancho = cx * 16
    val largo = cz * 16
    private val b = ByteArray(ancho * alto * largo)
    val sucio = BooleanArray(cx * cz) { true }
    val spawnX = ancho / 2
    val spawnZ = largo / 2

    init { generar() }

    private fun idx(x: Int, y: Int, z: Int) = (x * largo + z) * alto + y

    fun dentro(x: Int, y: Int, z: Int) = x >= 0 && z >= 0 && y >= 0 && x < ancho && z < largo && y < alto

    fun get(x: Int, y: Int, z: Int): Int {
        if (y >= alto) return 0
        if (y < 0 || x < 0 || z < 0 || x >= ancho || z >= largo) return 3   // paredes invisibles
        return b[idx(x, y, z)].toInt()
    }

    fun poner(x: Int, y: Int, z: Int, id: Int) {
        if (!dentro(x, y, z)) return
        b[idx(x, y, z)] = id.toByte()
        val a = x shr 4; val c = z shr 4
        sucio[a * cz + c] = true
        if ((x and 15) == 0 && a > 0) sucio[(a - 1) * cz + c] = true
        if ((x and 15) == 15 && a < cx - 1) sucio[(a + 1) * cz + c] = true
        if ((z and 15) == 0 && c > 0) sucio[a * cz + c - 1] = true
        if ((z and 15) == 15 && c < cz - 1) sucio[a * cz + c + 1] = true
    }

    fun alturaSup(x: Int, z: Int): Int {
        for (y in alto - 1 downTo 0) if (b[idx(x, y, z)].toInt() != 0) return y
        return 0
    }

    // ---------- generacion ----------
    private fun h2(x: Int, z: Int, s: Int): Float {
        var h = x * 374761393 + z * 668265263 + s * 1274126177
        h = (h xor (h ushr 13)) * 1274126177
        h = h xor (h ushr 16)
        return (h and 0xFFFF) / 65535f
    }

    private fun ruido(x: Float, z: Float, s: Int): Float {
        val xi = floor(x).toInt(); val zi = floor(z).toInt()
        var fx = x - xi; var fz = z - zi
        fx = fx * fx * (3 - 2 * fx); fz = fz * fz * (3 - 2 * fz)
        val a = h2(xi, zi, s); val b2 = h2(xi + 1, zi, s)
        val c = h2(xi, zi + 1, s); val d = h2(xi + 1, zi + 1, s)
        val arriba = a + (b2 - a) * fx
        val abajo = c + (d - c) * fx
        return arriba + (abajo - arriba) * fz
    }

    private fun cueva(x: Int, y: Int, z: Int): Boolean {
        val v = sin(x * 0.13f + semilla) * sin(z * 0.11f) + sin(y * 0.3f + x * 0.05f) * cos(z * 0.09f + 1f)
        return v > 1.4f
    }

    private fun generar() {
        val alturas = IntArray(ancho * largo)
        for (x in 0 until ancho) for (z in 0 until largo) {
            val h = (alto * 0.4f + (ruido(x / 40f, z / 40f, semilla) - 0.5f) * 22f +
                    (ruido(x / 14f, z / 14f, semilla + 1) - 0.5f) * 6f).toInt().coerceIn(6, alto - 12)
            alturas[x * largo + z] = h
            val arena = h <= 20
            for (y in 0..h) {
                var id = when {
                    y == 0 -> 3
                    y == h -> if (arena) 6 else 1
                    y >= h - 3 -> if (arena) 6 else 2
                    else -> if (h2(x * 7 + y, z * 13 + y, semilla + 3) < 0.03f) 9 else 3
                }
                if (y >= 4 && y < h - 5 && cueva(x, y, z)) id = 0
                b[idx(x, y, z)] = id.toByte()
            }
        }
        val pmin = Datos.arbol.getInt("altura_min"); val pmax = Datos.arbol.getInt("altura_max")
        val prob = Datos.arbol.getDouble("probabilidad").toFloat()
        for (x in 3 until ancho - 3) for (z in 3 until largo - 3) {
            if (abs(x - spawnX) < 4 && abs(z - spawnZ) < 4) continue
            if (h2(x, z, semilla + 5) >= prob) continue
            val h = alturas[x * largo + z]
            if (b[idx(x, h, z)].toInt() != 1) continue
            val th = pmin + minOf(pmax - pmin, (h2(x, z, semilla + 6) * (pmax - pmin + 1)).toInt())
            for (dy in th - 2..th + 1) {
                val r = if (dy >= th) 1 else 2
                for (dx in -r..r) for (dz in -r..r) {
                    if (r == 2 && abs(dx) == 2 && abs(dz) == 2) continue
                    if (dy == th + 1 && abs(dx) + abs(dz) > 1) continue
                    val yy = h + dy
                    if (yy < alto && b[idx(x + dx, yy, z + dz)].toInt() == 0) b[idx(x + dx, yy, z + dz)] = 5
                }
            }
            for (dy in 1..th) b[idx(x, h + dy, z)] = 4
        }
    }

    // ---------- rayo (para saber a que bloque apuntas) ----------
    fun rayo(ox: Float, oy: Float, oz: Float, dx: Float, dy: Float, dz: Float, max: Float): Golpe? {
        var x = floor(ox).toInt(); var y = floor(oy).toInt(); var z = floor(oz).toInt()
        val sx = if (dx > 0) 1 else -1; val sy = if (dy > 0) 1 else -1; val sz = if (dz > 0) 1 else -1
        val big = Float.MAX_VALUE
        val tdx = if (dx != 0f) abs(1f / dx) else big
        val tdy = if (dy != 0f) abs(1f / dy) else big
        val tdz = if (dz != 0f) abs(1f / dz) else big
        var tmx = if (dx > 0) (x + 1 - ox) * tdx else if (dx < 0) (ox - x) * tdx else big
        var tmy = if (dy > 0) (y + 1 - oy) * tdy else if (dy < 0) (oy - y) * tdy else big
        var tmz = if (dz > 0) (z + 1 - oz) * tdz else if (dz < 0) (oz - z) * tdz else big
        var nx = 0; var ny = 0; var nz = 0
        var t = 0f
        while (t <= max) {
            if (get(x, y, z) != 0) return Golpe(x, y, z, nx, ny, nz)
            if (tmx < tmy && tmx < tmz) { x += sx; t = tmx; tmx += tdx; nx = -sx; ny = 0; nz = 0 }
            else if (tmy < tmz) { y += sy; t = tmy; tmy += tdy; nx = 0; ny = -sy; nz = 0 }
            else { z += sz; t = tmz; tmz += tdz; nx = 0; ny = 0; nz = -sz }
        }
        return null
    }

    // ---------- guardado ----------
    fun guardar(f: File) {
        GZIPOutputStream(FileOutputStream(f)).use { it.write(b) }
    }

    fun cargar(f: File): Boolean {
        if (!f.exists()) return false
        return try {
            val tmp = ByteArray(b.size)
            GZIPInputStream(FileInputStream(f)).use { s ->
                var n = 0
                while (n < tmp.size) {
                    val r = s.read(tmp, n, tmp.size - n)
                    if (r < 0) break
                    n += r
                }
                if (n != tmp.size) return false
            }
            System.arraycopy(tmp, 0, b, 0, b.size)
            sucio.fill(true)
            true
        } catch (e: Exception) { false }
    }
}
