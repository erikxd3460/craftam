package com.craftam.game

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import android.util.Log
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

private const val VS = """
attribute vec3 aPos;
attribute vec2 aUv;
attribute float aSh;
uniform mat4 uMvp;
uniform float uFogI;
uniform float uFogF;
varying vec2 vUv;
varying float vSh;
varying float vFog;
void main() {
    vUv = aUv;
    vSh = aSh;
    gl_Position = uMvp * vec4(aPos, 1.0);
    vFog = clamp((gl_Position.w - uFogI) / (uFogF - uFogI), 0.0, 1.0);
}
"""

private const val FS = """
precision mediump float;
uniform sampler2D uTex;
uniform float uAlfa;
uniform vec3 uCielo;
varying vec2 vUv;
varying float vSh;
varying float vFog;
void main() {
    vec4 c = texture2D(uTex, vUv);
    gl_FragColor = vec4(mix(c.rgb * vSh, uCielo, vFog), c.a * uAlfa);
}
"""

private class Malla { var vbo = 0; var nv = 0 }

class Render(private val juego: Juego) : GLSurfaceView.Renderer {
    private val mundo = juego.mundo
    private val chunks = Array(mundo.cx * mundo.cz) { Malla() }
    private val cubo = Malla()
    private val aristas = Malla()
    private var prog = 0
    private var aPos = 0; private var aUv = 0; private var aSh = 0
    private var uMvp = 0; private var uAlfa = 0; private var uFogI = 0; private var uFogF = 0; private var uCielo = 0
    private val proj = FloatArray(16); private val view = FloatArray(16)
    private val vp = FloatArray(16); private val mvp = FloatArray(16)
    private var aspect = 1f
    private var t0 = System.nanoTime()
    private val vista = Datos.mundo.getInt("vista") * 16f

    override fun onSurfaceCreated(gl: GL10?, cfg: EGLConfig?) {
        GLES20.glClearColor(0.55f, 0.78f, 0.95f, 1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)

        prog = GLES20.glCreateProgram()
        GLES20.glAttachShader(prog, shader(GLES20.GL_VERTEX_SHADER, VS))
        GLES20.glAttachShader(prog, shader(GLES20.GL_FRAGMENT_SHADER, FS))
        GLES20.glLinkProgram(prog)
        aPos = GLES20.glGetAttribLocation(prog, "aPos"); aUv = GLES20.glGetAttribLocation(prog, "aUv"); aSh = GLES20.glGetAttribLocation(prog, "aSh")
        uMvp = GLES20.glGetUniformLocation(prog, "uMvp"); uAlfa = GLES20.glGetUniformLocation(prog, "uAlfa")
        uFogI = GLES20.glGetUniformLocation(prog, "uFogI"); uFogF = GLES20.glGetUniformLocation(prog, "uFogF")
        uCielo = GLES20.glGetUniformLocation(prog, "uCielo")

        val t = IntArray(1)
        GLES20.glGenTextures(1, t, 0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, t[0])
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_NEAREST)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_NEAREST)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, Atlas.bmp, 0)

        // El contexto es nuevo: los buffers viejos ya no existen
        for (c in chunks) { c.vbo = 0; c.nv = 0 }
        cubo.vbo = 0; aristas.vbo = 0
        subir(cubo, Mallador.cubo(), 36 * 6)
        subir(aristas, Mallador.aristas(), 24 * 6)
        mundo.sucio.fill(true)
        t0 = System.nanoTime()
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        GLES20.glViewport(0, 0, w, h)
        aspect = w.toFloat() / max(1, h)
    }

    override fun onDrawFrame(gl: GL10?) {
        val ahora = System.nanoTime()
        val dt = min(0.05f, (ahora - t0) / 1e9f); t0 = ahora
        juego.actualizar(dt)
        remallar()

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        GLES20.glUseProgram(prog)
        val j = juego.jug
        val d = j.mirar()
        val ey = j.y + j.ojos
        Matrix.perspectiveM(proj, 0, 70f, aspect, 0.1f, 300f)
        Matrix.setLookAtM(view, 0, j.x, ey, j.z, j.x + d[0], ey + d[1], j.z + d[2], 0f, 1f, 0f)
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)

        GLES20.glUniform1f(uFogI, vista - 24f); GLES20.glUniform1f(uFogF, vista - 4f)
        GLES20.glUniform3f(uCielo, 0.55f, 0.78f, 0.95f)
        GLES20.glUniform1f(uAlfa, 1f)
        GLES20.glUniformMatrix4fv(uMvp, 1, false, vp, 0)
        GLES20.glEnableVertexAttribArray(aPos); GLES20.glEnableVertexAttribArray(aUv); GLES20.glEnableVertexAttribArray(aSh)

        val lx = d[0]; val lz = d[2]
        val ln = max(0.001f, sqrt(lx * lx + lz * lz))
        for (i in chunks.indices) {
            val c = chunks[i]
            if (c.nv == 0) continue
            val dx = (i / mundo.cz) * 16 + 8 - j.x; val dz = (i % mundo.cz) * 16 + 8 - j.z
            val dist = sqrt(dx * dx + dz * dz)
            if (dist > vista) continue
            if (dist > 20f && (dx * lx + dz * lz) / ln < 0f) continue   // detras de la camara
            dibujar(c, GLES20.GL_TRIANGLES)
        }

        // marca del bloque al que apuntas
        val o = juego.objetivo
        if (o != null) {
            System.arraycopy(vp, 0, mvp, 0, 16)
            Matrix.translateM(mvp, 0, o.x.toFloat(), o.y.toFloat(), o.z.toFloat())
            GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
            val p = juego.prog
            if (p > 0f) { GLES20.glUniform1f(uAlfa, p * 0.6f); dibujar(cubo, GLES20.GL_TRIANGLES) }
            GLES20.glUniform1f(uAlfa, 1f)
            GLES20.glLineWidth(3f)
            dibujar(aristas, GLES20.GL_LINES)
        }
    }

    private fun dibujar(m: Malla, modo: Int) {
        if (m.vbo == 0 || m.nv == 0) return
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, m.vbo)
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 24, 0)
        GLES20.glVertexAttribPointer(aUv, 2, GLES20.GL_FLOAT, false, 24, 12)
        GLES20.glVertexAttribPointer(aSh, 1, GLES20.GL_FLOAT, false, 24, 20)
        GLES20.glDrawArrays(modo, 0, m.nv)
    }

    /** Reconstruye hasta 3 chunks modificados por cuadro, los mas cercanos primero. */
    private fun remallar() {
        val j = juego.jug
        for (veces in 0 until 3) {
            var mejor = -1; var md = Float.MAX_VALUE
            for (i in chunks.indices) {
                if (!mundo.sucio[i]) continue
                val dx = (i / mundo.cz) * 16 + 8 - j.x; val dz = (i % mundo.cz) * 16 + 8 - j.z
                val d = dx * dx + dz * dz
                if (d < md) { md = d; mejor = i }
            }
            if (mejor < 0) return
            mundo.sucio[mejor] = false
            val n = Mallador.construir(mundo, mejor / mundo.cz, mejor % mundo.cz)
            subir(chunks[mejor], Mallador.buf, n)
        }
    }

    private fun subir(m: Malla, datos: FloatArray, n: Int) {
        if (n == 0) { m.nv = 0; return }
        if (m.vbo == 0) { val a = IntArray(1); GLES20.glGenBuffers(1, a, 0); m.vbo = a[0] }
        val fb = ByteBuffer.allocateDirect(n * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        fb.put(datos, 0, n); fb.position(0)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, m.vbo)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, n * 4, fb, GLES20.GL_STATIC_DRAW)
        m.nv = n / 6
    }

    private fun shader(tipo: Int, src: String): Int {
        val s = GLES20.glCreateShader(tipo)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) Log.e("Craftam", "Error de shader: " + GLES20.glGetShaderInfoLog(s))
        return s
    }
}
