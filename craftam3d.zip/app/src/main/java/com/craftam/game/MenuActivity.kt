package com.craftam.game

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.StateListDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import kotlin.math.max
import kotlin.math.min

class MenuActivity : Activity() {
    private var W = 0
    private var H = 0

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Assets.init(this); Datos.cargar(); Sonido.init(this)
        val dm = resources.displayMetrics
        W = max(dm.widthPixels, dm.heightPixels); H = min(dm.widthPixels, dm.heightPixels)
        val cfg = Datos.menu

        val raiz = FrameLayout(this)
        val fondo = ImageView(this)
        fondo.scaleType = ImageView.ScaleType.CENTER_CROP
        fondo.setImageDrawable(nitido(Assets.bitmap("menu/texture/" + cfg.getString("fondo"))))
        raiz.addView(fondo, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER
        val logo = ImageView(this)
        logo.adjustViewBounds = true
        logo.setImageDrawable(nitido(Assets.bitmap("menu/logo/" + cfg.getString("logo"))))
        col.addView(logo, LinearLayout.LayoutParams((W * 0.5f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT))

        val bs = cfg.getJSONArray("botones")
        for (i in 0 until bs.length()) {
            val o = bs.getJSONObject(i)
            val accion = o.getString("accion")
            val btn = boton(o.getString("texto")) { pulsar(accion) }
            if (accion == "sonido") textoSonido(btn)
            val lp = LinearLayout.LayoutParams((W * 0.4f).toInt(), (H * 0.12f).toInt())
            lp.topMargin = (H * 0.02f).toInt()
            col.addView(btn, lp)
            if (accion == "sonido") btn.setOnClickListener { Sonido.tocar("click"); Sonido.cambiar(this); textoSonido(btn) }
        }
        raiz.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(raiz)
    }

    private fun textoSonido(b: Button) { b.text = "Sonido: " + (if (Sonido.activo) "SI" else "NO") }

    private fun pulsar(accion: String) {
        when (accion) {
            "jugar" -> startActivity(Intent(this, JuegoActivity::class.java))
            "nuevo" -> { Juego.borrarPartida(this); startActivity(Intent(this, JuegoActivity::class.java)) }
            "salir" -> finish()
        }
    }

    private fun nitido(bmp: Bitmap): Drawable {
        val d = BitmapDrawable(resources, bmp)
        d.setFilterBitmap(false)
        return d
    }

    private fun boton(texto: String, alPulsar: () -> Unit): Button {
        val b = Button(this)
        b.text = texto
        b.setAllCaps(false)
        b.setTextColor(Color.WHITE)
        b.setTextSize(TypedValue.COMPLEX_UNIT_PX, H * 0.05f)
        val sl = StateListDrawable()
        sl.addState(intArrayOf(android.R.attr.state_pressed), nitido(Assets.bitmap("menu/texture/boton_pulsado.png")))
        sl.addState(intArrayOf(), nitido(Assets.bitmap("menu/texture/boton.png")))
        b.background = sl
        b.setOnClickListener { Sonido.tocar("click"); alPulsar() }
        return b
    }
}
