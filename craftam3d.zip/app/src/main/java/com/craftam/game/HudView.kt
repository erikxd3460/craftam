package com.craftam.game

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sqrt

/** Capa de controles tactiles: joystick (izquierda), mirar (arrastrar a la derecha), botones y barra de items. */
class HudView(ctx: Context, private val juego: Juego, private val alCraft: () -> Unit) : View(ctx) {
    private val cfg = Datos.hud
    private val sens = cfg.getDouble("sensibilidad").toFloat()
    private val zonaJoy = cfg.getDouble("zona_joystick").toFloat()

    private val pBmp = Paint().apply { isFilterBitmap = false }
    private val pTxt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.RIGHT; setShadowLayer(3f, 1f, 1f, Color.BLACK) }
    private val pLinea = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 4f; color = Color.argb(150, 255, 255, 255) }
    private val pRelleno = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.argb(110, 255, 255, 255) }

    private val bSlot = Assets.bitmap("$TC/texture/slot.png")
    private val bSel = Assets.bitmap("$TC/texture/slot_sel.png")
    private val bSalto = Assets.bitmap("$TC/texture/btn_salto.png")
    private val bPicar = Assets.bitmap("$TC/texture/btn_picar.png")
    private val bPoner = Assets.bitmap("$TC/texture/btn_poner.png")
    private val bCraft = Assets.bitmap("$TC/texture/btn_craft.png")
    private val iconos = HashMap<Int, Bitmap>()

    private val roles = HashMap<Int, Int>()          // id del dedo -> rol
    private val ultimo = HashMap<Int, FloatArray>()  // [x, y, xInicial, yInicial, 1 si esta picando]
    private val inicio = HashMap<Int, Long>()        // cuando empezo el toque (para tap = poner, mantener = picar)
    private var jox = 0f; private var joy = 0f; private var jtx = 0f; private var jty = 0f
    private var joyActivo = false

    private val rSalto = RectF(); private val rPicar = RectF(); private val rPoner = RectF(); private val rCraft = RectF()
    private val tmp = RectF()
    private val HOT = 8
    private var radio = 100f; private var slot = 100f; private var slotX0 = 0f; private var slotY0 = 0f
    private var margen = 30f

    companion object { const val JOY = 1; const val MIRAR = 2; const val SALTO = 3; const val PICAR = 4; const val PONER = 5; const val CRAFT = 6; const val SLOT = 7 }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val s = h * cfg.getDouble("boton").toFloat()
        margen = s * 0.35f
        radio = h * cfg.getDouble("joystick").toFloat()
        rSalto.set(w - margen - s, h - margen - s, w - margen, h - margen)
        rPicar.set(w - margen - s, h - margen - 2.2f * s, w - margen, h - margen - 1.2f * s)
        rPoner.set(w - margen - s, h - margen - 3.4f * s, w - margen, h - margen - 2.4f * s)
        rCraft.set(margen, margen, margen + s * 0.8f, margen + s * 0.8f)
        slot = h * 0.11f
        slotX0 = (w - slot * HOT) / 2f
        slotY0 = h - slot - margen * 0.5f
    }

    private fun icono(id: Int): Bitmap = iconos.getOrPut(id) {
        val o = Datos.obj(id)
        Assets.bitmap("$GH/${o.carpeta}/${o.icono}")
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        // mantener el dedo quieto en la pantalla = picar
        val ahora = SystemClock.uptimeMillis()
        for ((id, u) in ultimo) {
            if (roles[id] == MIRAR && u[4] == 0f && ahora - (inicio[id] ?: ahora) > 300 && hypot(u[0] - u[2], u[1] - u[3]) < 25f) {
                u[4] = 1f; Entrada.picar = true
            }
        }
        // mira
        c.drawLine(w / 2 - 16, h / 2, w / 2 + 16, h / 2, pLinea)
        c.drawLine(w / 2, h / 2 - 16, w / 2, h / 2 + 16, pLinea)
        // joystick
        val bx = if (joyActivo) jox else margen + radio * 1.2f
        val by = if (joyActivo) joy else h - margen - radio * 1.2f
        c.drawCircle(bx, by, radio, pLinea)
        c.drawCircle(bx + jtx * radio, by + jty * radio, radio * 0.4f, pRelleno)
        // botones
        dibujarBoton(c, bSalto, rSalto, SALTO); dibujarBoton(c, bPicar, rPicar, PICAR)
        dibujarBoton(c, bPoner, rPoner, PONER); dibujarBoton(c, bCraft, rCraft, CRAFT)
        // barra de items
        val lista = juego.inv.lista(); val sel = juego.inv.sel
        val ini = max(0, sel - (HOT - 1))
        pBmp.alpha = 255
        pTxt.textSize = slot * 0.3f
        for (k in 0 until HOT) {
            val j = ini + k
            val x = slotX0 + k * slot
            tmp.set(x, slotY0, x + slot, slotY0 + slot)
            c.drawBitmap(if (j == sel && j < lista.size) bSel else bSlot, null, tmp, pBmp)
            if (j < lista.size) {
                val m = slot * 0.15f
                tmp.set(x + m, slotY0 + m, x + slot - m, slotY0 + slot - m)
                c.drawBitmap(icono(lista[j][0]), null, tmp, pBmp)
                c.drawText(lista[j][1].toString(), x + slot - 6f, slotY0 + slot - 6f, pTxt)
            }
        }
        postInvalidateOnAnimation()
    }

    private fun dibujarBoton(c: Canvas, b: Bitmap, r: RectF, rol: Int) {
        pBmp.alpha = if (roles.containsValue(rol)) 255 else 170
        c.drawBitmap(b, null, r, pBmp)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                abajo(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_MOVE -> for (i in 0 until e.pointerCount) mover(e.getPointerId(i), e.getX(i), e.getY(i))
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> arriba(e.getPointerId(e.actionIndex))
            MotionEvent.ACTION_CANCEL -> soltarTodo()
        }
        return true
    }

    override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
        super.onWindowFocusChanged(hasWindowFocus)
        if (!hasWindowFocus) soltarTodo()
    }

    private fun soltarTodo() {
        for (id in roles.keys.toList()) arriba(id)
    }

    private fun abajo(id: Int, x: Float, y: Float) {
        when {
            rCraft.contains(x, y) -> { roles[id] = CRAFT; alCraft() }
            rSalto.contains(x, y) -> { roles[id] = SALTO; Entrada.saltar = true }
            rPicar.contains(x, y) -> { roles[id] = PICAR; Entrada.picar = true }
            rPoner.contains(x, y) -> { roles[id] = PONER; Entrada.pedirPoner() }
            y >= slotY0 && x >= slotX0 && x <= slotX0 + slot * HOT -> {
                roles[id] = SLOT
                val k = ((x - slotX0) / slot).toInt()
                juego.inv.seleccionar(max(0, juego.inv.sel - (HOT - 1)) + k)
            }
            x < width * zonaJoy && !roles.containsValue(JOY) -> {
                roles[id] = JOY; jox = x; joy = y; joyActivo = true
                mover(id, x, y)
            }
            else -> { roles[id] = MIRAR; ultimo[id] = floatArrayOf(x, y, x, y, 0f); inicio[id] = SystemClock.uptimeMillis() }
        }
    }

    private fun mover(id: Int, x: Float, y: Float) {
        when (roles[id]) {
            JOY -> {
                var dx = (x - jox) / radio; var dy = (y - joy) / radio
                val l = sqrt(dx * dx + dy * dy)
                if (l > 1f) { dx /= l; dy /= l }
                jtx = dx; jty = dy
                if (l < 0.15f) { Entrada.jx = 0f; Entrada.jy = 0f } else { Entrada.jx = dx; Entrada.jy = -dy }
            }
            MIRAR -> {
                val u = ultimo[id]
                if (u != null) { Entrada.mirar((x - u[0]) * sens, (y - u[1]) * sens); u[0] = x; u[1] = y }
            }
        }
    }

    private fun arriba(id: Int) {
        when (roles.remove(id)) {
            JOY -> { joyActivo = false; jtx = 0f; jty = 0f; Entrada.jx = 0f; Entrada.jy = 0f }
            SALTO -> Entrada.saltar = false
            PICAR -> Entrada.picar = false
            MIRAR -> {
                val u = ultimo[id]; val t = inicio[id]
                if (u != null) {
                    if (u[4] == 1f) Entrada.picar = roles.containsValue(PICAR)
                    else if (t != null && SystemClock.uptimeMillis() - t < 250 && hypot(u[0] - u[2], u[1] - u[3]) < 25f) Entrada.pedirPoner()
                }
            }
        }
        ultimo.remove(id); inicio.remove(id)
    }
}
