package com.craftam.game

import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.sin

class Jugador {
    var x = 0f; var y = 0f; var z = 0f      // x,z = centro; y = pies
    var vy = 0f
    var yaw = 0f; var pitch = 0f
    var suelo = false

    private val mitad = Datos.fis.getDouble("ancho").toFloat() / 2f
    private val alto = Datos.fis.getDouble("alto").toFloat()
    val ojos = Datos.fis.getDouble("ojos").toFloat()
    private val vel = Datos.fis.getDouble("velocidad").toFloat()
    private val vSalto = Datos.fis.getDouble("salto").toFloat()
    private val grav = Datos.fis.getDouble("gravedad").toFloat()

    /** Vector hacia donde mira la camara. */
    fun mirar(): FloatArray {
        val cp = cos(pitch)
        return floatArrayOf(sin(yaw) * cp, sin(pitch), -cos(yaw) * cp)
    }

    private fun choca(m: Mundo): Boolean {
        val x0 = floor(x - mitad).toInt(); val x1 = floor(x + mitad).toInt()
        val y0 = floor(y).toInt(); val y1 = floor(y + alto - 1e-4f).toInt()
        val z0 = floor(z - mitad).toInt(); val z1 = floor(z + mitad).toInt()
        for (xx in x0..x1) for (yy in y0..y1) for (zz in z0..z1) if (m.get(xx, yy, zz) != 0) return true
        return false
    }

    fun ocupa(bx: Int, by: Int, bz: Int): Boolean =
        x - mitad < bx + 1 && x + mitad > bx && y < by + 1 && y + alto > by && z - mitad < bz + 1 && z + mitad > bz

    /** jx: derecha(+)/izquierda(-), jy: adelante(+)/atras(-). Devuelve true si acaba de saltar. */
    fun mover(m: Mundo, dt: Float, jx: Float, jy: Float, salta: Boolean): Boolean {
        val s = sin(yaw); val c = cos(yaw)
        val mx = (jx * c + jy * s) * vel
        val mz = (jx * s - jy * c) * vel
        var saltoAhora = false
        if (salta && suelo) { vy = vSalto; saltoAhora = true }
        vy = max(vy - grav * dt, -25f)

        x += mx * dt
        if (mx != 0f && choca(m)) x = if (mx > 0) floor(x + mitad) - mitad - 1e-3f else floor(x - mitad) + 1f + mitad + 1e-3f
        z += mz * dt
        if (mz != 0f && choca(m)) z = if (mz > 0) floor(z + mitad) - mitad - 1e-3f else floor(z - mitad) + 1f + mitad + 1e-3f

        y += vy * dt
        suelo = false
        if (choca(m)) {
            if (vy < 0) { y = floor(y) + 1f; suelo = true } else y = floor(y + alto) - alto - 1e-3f
            vy = 0f
        }
        return saltoAhora
    }
}
