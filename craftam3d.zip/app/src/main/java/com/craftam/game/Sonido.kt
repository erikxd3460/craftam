package com.craftam.game

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool

object Sonido {
    private var sp: SoundPool? = null
    private val ids = HashMap<String, Int>()
    var activo = true

    fun init(c: Context) {
        activo = c.getSharedPreferences("ajustes", Context.MODE_PRIVATE).getBoolean("sonido", true)
        if (sp != null) return
        val s = SoundPool.Builder().setMaxStreams(6)
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()).build()
        val lista = listOf("romper" to "$GH/saund/romper.wav", "poner" to "$GH/saund/poner.wav",
            "saltar" to "$GH/saund/saltar.wav", "craft" to "$GH/saund/craft.wav", "click" to "menu/saund/click.wav")
        for ((clave, ruta) in lista) c.assets.openFd(ruta).use { ids[clave] = s.load(it, 1) }
        sp = s
    }

    fun cambiar(c: Context): Boolean {
        activo = !activo
        c.getSharedPreferences("ajustes", Context.MODE_PRIVATE).edit().putBoolean("sonido", activo).apply()
        return activo
    }

    fun tocar(nombre: String) {
        if (!activo) return
        val id = ids[nombre] ?: return
        sp?.play(id, 1f, 1f, 1, 0, 1f)
    }
}
